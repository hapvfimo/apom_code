python main.py $1 $2 $3 >> test.log;
#echo $1' '$2' '$3;
