""" this is main file that get executed as main process """
import os
import sys

for arg in sys.argv:
	print arg

#print sys.argv[1] + " " + sys.argv[2] + " " + sys.argv[3];
